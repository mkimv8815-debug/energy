// 空的 Service Worker，仅用于启用 PWA 安装提示
self.addEventListener('fetch', () => {});